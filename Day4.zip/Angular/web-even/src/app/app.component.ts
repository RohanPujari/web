import { Component } from '@angular/core';
import { Variable } from '@angular/compiler/src/render3/r3_ast';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'web-even';
  num1:number;
  result:String
  check_number():void {
    alert("Function called");
    this.num1 = document.getElementById("txtNumber").value;
    console.log("num1: "+this.num1);
    if(this.num1%2==0){
      this.result="Number="+this.num1+" is even";
    }
    else
    this.result="Number="+ this.num1+" is odd";
  }
}
