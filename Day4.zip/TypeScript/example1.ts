function greeting(person){
    return "Welcome to typescript"+person;

}
var user="Rohan";
greeting(user);