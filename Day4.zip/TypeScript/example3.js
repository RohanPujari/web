function greeting(person) {
    return "Welcome to typescript " + person.first_name + " " + person.last_name;
}
//let user=true;
var user = { first_name: "rohan", last_name: "pujari" };
//user.first_name="rohan";
//user.last_name="pujari";
document.getElementById("result").innerHTML = greeting(user);
