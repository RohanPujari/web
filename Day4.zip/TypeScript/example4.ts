interface Person{
    first_name:string;
    last_name:string;
}
class Student implements Person{
    first_name:string;
    last_name:string;
    constructor(fname:string,lname:string){               //delcaring a variable in ts
        this.first_name=fname;
        this.last_name=lname;
    }
    

 greeting():string{                   //no need to specify function keyword
    return "Welcome to typescript "+this.first_name+" "+this.last_name ;
    }

}
let student1 = new Student("Rohan","Pujari");


document.getElementById("result").innerHTML= student1.greeting();
