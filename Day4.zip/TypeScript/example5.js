function Employee(fname,lname){                //Equals to creating a class
    this.first_name = fname;
    this.last_name = lname;
   // this.display = function(){                  //this will create no of objects.THIS IS NOT A GOOD PLACE TO DECLARE.
       // console.log("Display is method of Employee");
    //}

}
Employee.prototype.display=function(){
    console.log("Display is method of Employee");
}