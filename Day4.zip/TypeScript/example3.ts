interface Person{
    first_name:string;
    last_name:string;
}
function greeting(person:Person){
    return "Welcome to typescript "+person.first_name+" "+person.last_name ;

}
//let user=true;
let user:Person={first_name:"rohan" , last_name:"pujari"};
//user.first_name="rohan";
//user.last_name="pujari";
document.getElementById("result").innerHTML=greeting(user);