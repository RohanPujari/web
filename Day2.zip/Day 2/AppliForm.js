function appliform(){
    var name=document.getElementById("fullname").value;
if(name==1 && name==2 && name==3 && name==4 && name==5 && name==6 && name==7 && name==8 && name==9 && name==0 ){
    document.getElementById("name-error").innerHTML="Alphabet are required.";
}
if(name==""){
    document.getElementById("name-error").innerHTML="Alphabet is required.";
}
    else
    document.getElementById("name-error").innerHTML="";

    var num=document.getElementById("code").value;
    if(num==0 && num==1 && num==2 && num==3 && num==4 && num==5 && num==6 && num==7 && num==8 && num==9){
        document.getElementById("code-error").innerHTML="";
    }
    else
    document.getElementById("code-error").innerHTML="Check the number";

}