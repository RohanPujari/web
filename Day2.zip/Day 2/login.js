function validateForm(){
    alert("Validate function is called.")
    var user=document.getElementById("username").value;
    var pass=document.getElementById("password").value;
if(user!="" && pass!=""){
    document.getElementById("frm").submit();
}
else{
    alert("Username and password required. Please enter both");
    }
}